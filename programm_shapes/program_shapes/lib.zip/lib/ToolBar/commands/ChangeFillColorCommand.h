#pragma once
#include "ICommand.h"
#include "../../shapes/C�ompositionShapes.h"
#include <SFML/Graphics/Color.hpp>

class ChangeFillColorCommand : public ICommand
{
public:
	ChangeFillColorCommand(std::shared_ptr<C�ompositionShapes> compositionShapes, const sf::Color& newColor);
	void Execute() override;
private:
	std::shared_ptr<C�ompositionShapes> m_compositionShapes;
	sf::Color m_newColor;
};
	
