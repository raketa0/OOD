#pragma once
#include "ICommand.h"
#include "../../shapes/C�ompositionShapes.h"
#include <SFML/Graphics/Color.hpp>

class ChangeOutlineColorCommand : public ICommand
{
public:
	ChangeOutlineColorCommand(std::shared_ptr<C�ompositionShapes> compositionShapes, const sf::Color& newColor);
	void Execute() override;
private:
	std::shared_ptr<C�ompositionShapes> m_compositionShapes;
	sf::Color m_newColor;
};
	
