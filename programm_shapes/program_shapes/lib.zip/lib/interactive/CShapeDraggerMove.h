#pragma once

#include "../shapes/C�ompositionShapes.h"
#include "CShapeSelector.h"
#include <SFML/Graphics.hpp>
#include <memory>

class CShapeDraggerMove
{
public:
    CShapeDraggerMove(std::shared_ptr<C�ompositionShapes> composition, CShapeSelector& selector);

    void StartDrag(const sf::Vector2i& mousePosition);
    void OnMouseMoved(const sf::Vector2i& mousePosition);
    void EndDrag();

private:
    std::shared_ptr<C�ompositionShapes> m_composition;
    CShapeSelector& m_selector;
    bool m_isDragging = false;
    sf::Vector2i m_dragOffset;

    void MoveSelectedShapes(int deltaX, int deltaY);
};