#pragma once
#include "ICommand.h"
#include "../../shapes/C�ompositionShapes.h"
#include <memory>
#include <SFML/Graphics/Color.hpp>

class ChangeOutlineThicknessCommand : public ICommand
{
public:
	ChangeOutlineThicknessCommand(std::shared_ptr<C�ompositionShapes> compositionShapes, float newThickness);

	void Execute() override;
private:
	std::shared_ptr<C�ompositionShapes> m_compositionShapes;
	float m_newThickness;
};
