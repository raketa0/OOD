#pragma once
#include "Application.h"


void Run()
{
    Application::GetApp().Run();
}


