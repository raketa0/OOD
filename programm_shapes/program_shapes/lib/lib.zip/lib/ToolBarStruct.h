#pragma once
#include <string>
#include <SFML/Graphics.hpp>

enum Tool
{
	SELECT,
	ADD_CIRCLE,
    ADD_RECTANGLE,
	ADD_TRIANGLE,
	FILL,
	LINE
};


