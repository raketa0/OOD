#pragma once
#include "IMementoShapes.h"
#include "../shapes/C�ompositionShapes.h"

class CompositionShapesMemento : public IMementoShapes
{
public:
    CompositionShapesMemento(C�ompositionShapes& composition);

    void Restore() override;

private:
    C�ompositionShapes& m_composition;
    std::map<int, std::shared_ptr<IShape>> m_shapes;
};
