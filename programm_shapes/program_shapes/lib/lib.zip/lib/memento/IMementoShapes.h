#pragma once
#include <memory>
#include <map>

class IMementoShapes
{
public:
	virtual void Restore() = 0;
};

