#include "CompositionShapesMemento.h"

CompositionShapesMemento::CompositionShapesMemento(C�ompositionShapes& composition)
    : m_composition(composition)
{
    for (auto& [id, shape] : composition.Get�ompositionShapes())
    {
        if (!shape)
        {
            continue;
        }
        m_shapes[id] = shape->CreateMemento();
    }
}

void CompositionShapesMemento::Restore()
{
    m_composition.SetCompositionShapes(m_shapes);
}
